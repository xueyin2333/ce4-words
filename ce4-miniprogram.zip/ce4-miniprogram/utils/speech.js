// 朗读：小程序没有浏览器的 speechSynthesis，要用「微信同声传译」插件。
// 没装插件时降级成提示，不影响背词。
// 装法见 README「发音」一节。

let plugin = null;
let audio = null;
let warned = false;

function getPlugin() {
  if (plugin) return plugin;
  try {
    plugin = requirePlugin('WechatSI');
  } catch (e) {
    plugin = null;
  }
  return plugin;
}

function speak(word) {
  const text = String(word || '').trim();
  if (!text) return;

  const p = getPlugin();
  if (!p) {
    if (!warned) {
      warned = true;
      wx.showToast({ title: '还没装发音插件，看 README', icon: 'none', duration: 2400 });
    }
    return;
  }

  p.textToSpeech({
    lang: 'en_US',
    tts: true,
    content: text,
    success: function (res) {
      if (!res || !res.filename) return;
      if (!audio) {
        audio = wx.createInnerAudioContext();
        audio.onError(function (err) { console.warn('[speech] 播放失败', err); });
      }
      audio.stop();
      audio.src = res.filename;
      audio.play();
    },
    fail: function (err) {
      console.warn('[speech] 合成失败', err);
      wx.showToast({ title: '发音失败', icon: 'none' });
    }
  });
}

module.exports = { speak: speak };
