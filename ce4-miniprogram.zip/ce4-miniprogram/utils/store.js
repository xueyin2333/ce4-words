// 学习进度状态机，和网页版 ce4words 的逻辑保持一致
const V = require('../data/words.js');

const KEY = 'ce4_state_v1';

const DEF = {
  ver: 1,
  perDay: 12,   // 每日新词
  order: null,  // 洗牌后的学习顺序（存下标）
  seen: {},     // { 下标: 1 }
  learned: [],  // 已学下标，按学习先后
  wrong: {},    // { 下标: 错误次数 }，复习答对会减
  days: {},     // { '2026-11-17': { plan: [], done: [], right, wrong } }
  streak: 0,
  lastDay: null
};

let S = null;
let sess = null;

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = a[i];
    a[i] = a[j];
    a[j] = t;
  }
  return a;
}

function pad(n) {
  return n < 10 ? '0' + n : '' + n;
}

function dayKey(d) {
  const t = d || new Date();
  return t.getFullYear() + '-' + pad(t.getMonth() + 1) + '-' + pad(t.getDate());
}

function ydayKey() {
  return dayKey(new Date(Date.now() - 86400000));
}

function save() {
  try {
    wx.setStorageSync(KEY, S);
  } catch (e) {
    console.warn('[store] 保存失败', e);
  }
}

function init() {
  if (S) return S;

  let raw = null;
  try {
    raw = wx.getStorageSync(KEY);
  } catch (e) {
    console.warn('[store] 读取失败', e);
  }

  let s = raw && typeof raw === 'object' ? raw : null;
  if (!s || s.ver !== 1) s = {};

  S = Object.assign({}, DEF, s);
  if (!Array.isArray(S.order) || S.order.length !== V.length) {
    S.order = shuffle(V.map(function (_, i) { return i; }));
  }
  if (!S.seen) S.seen = {};
  if (!S.wrong) S.wrong = {};
  if (!Array.isArray(S.learned)) S.learned = [];
  if (!S.days) S.days = {};
  save();
  return S;
}

function today() {
  init();
  const k = dayKey();
  if (!S.days[k]) {
    S.days[k] = { plan: null, done: [], right: 0, wrong: 0 };
  }
  return S.days[k];
}

/** 今日计划：第一次访问时从未学过的词里抽 perDay 个 */
function plan() {
  const d = today();
  if (!d.plan) {
    d.plan = S.order.filter(function (i) { return !S.seen[i]; }).slice(0, S.perDay);
    save();
  }
  return d.plan;
}

function remaining() {
  const d = today();
  if (!d.plan) plan(); // 新的一天直接点「开始背」时，计划还没生成
  return d.plan.filter(function (i) { return d.done.indexOf(i) < 0; });
}

function wrongList() {
  init();
  return Object.keys(S.wrong)
    .map(Number)
    .filter(function (i) { return S.wrong[i] > 0; })
    .sort(function (a, b) { return S.wrong[b] - S.wrong[a]; });
}

function bumpStreak() {
  const k = dayKey();
  if (S.lastDay === k) return;
  S.streak = S.lastDay === ydayKey() ? (S.streak || 0) + 1 : 1;
  S.lastDay = k;
  save();
}

function wordAt(i) {
  const w = V[i] || ['', '', '', '', '', ''];
  return {
    index: i,
    word: w[0] || '',
    mean: w[1] || '',
    ipa: w[2] || '',
    ex: w[3] || '',
    emoji: w[4] || '',
    exz: w[5] || ''
  };
}

/* ---------- 会话 ---------- */

function newSession(ids, mode) {
  sess = {
    queue: ids.slice(),
    total: ids.length,
    mode: mode || 'new',
    revealed: false,
    right: 0,
    wrong: 0,
    answered: 0,
    mistakes: {}
  };
  return sess;
}

function session() {
  return sess;
}

function clearSession() {
  sess = null;
}

function reveal() {
  if (sess) sess.revealed = true;
}

/** 从今日剩余计划开始；计划已做完就自动补一组新词 */
function startStudy() {
  init();
  let left = remaining();

  if (!left.length) {
    const next = S.order.filter(function (i) { return !S.seen[i]; });
    if (!next.length) return { ok: false, reason: 'all-done' };
    const add = next.slice(0, S.perDay);
    const d = today();
    d.plan = (d.plan || []).concat(add);
    save();
    left = add;
  }

  return { ok: true, session: newSession(left, 'new') };
}

function startReview() {
  const ids = wrongList();
  if (!ids.length) return { ok: false, reason: 'empty' };
  return { ok: true, session: newSession(ids, 'review') };
}

/** 记一次作答；同一轮里错过的词会再出现一次 */
function answer(ok) {
  if (!sess || !sess.queue.length) return { finished: true };

  const s = sess;
  const i = s.queue.shift();
  const d = today();

  s.answered++;
  s.revealed = false;

  if (S.lastDay !== dayKey()) bumpStreak(); // 今天第一次作答就算打卡

  if (ok) {
    s.right++;
    if (!S.seen[i]) {
      S.seen[i] = 1;
      S.learned.push(i);
    }
    if (d.plan && d.plan.indexOf(i) >= 0 && d.done.indexOf(i) < 0) d.done.push(i);
    d.right++;
    if (s.mode === 'review') {
      S.wrong[i] = (S.wrong[i] || 0) - 1;
      if (S.wrong[i] <= 0) delete S.wrong[i];
    }
  } else {
    s.wrong++;
    d.wrong++;
    S.wrong[i] = (S.wrong[i] || 0) + 1;
    if (!S.seen[i]) {
      S.seen[i] = 1;
      S.learned.push(i);
    }
    const times = s.mistakes[i] || 0;
    s.mistakes[i] = times + 1;
    if (times < 1) s.queue.push(i); // 同一轮里再考一次
  }

  let finished = false;
  if (s.queue.length === 0) {
    bumpStreak();
    finished = true;
  }

  save();
  return { finished: finished };
}

/** 本轮统计，给总结页用 */
function result() {
  const s = sess || { mode: 'new', right: 0, wrong: 0, answered: 0 };
  const d = today();
  const pl = plan();
  const left = remaining();
  return {
    mode: s.mode,
    right: s.right,
    wrong: s.wrong,
    acc: s.answered ? Math.round((s.right / s.answered) * 100) : 0,
    doneCnt: pl.length - left.length,
    total: pl.length,
    left: left.length,
    learnedCount: S.learned.length,
    wrongCount: wrongList().length
  };
}

/* ---------- 视图数据 ---------- */

function getHome() {
  init();
  const d = today();
  const pl = plan();
  const left = remaining();
  const n = left.length;
  const total = pl.length;
  const doneCnt = pl.length - n;
  const allDone = Object.keys(S.seen).length >= V.length;

  let mainLabel;
  if (n > 0) {
    mainLabel = doneCnt > 0 ? '继续背（剩 ' + n + ' 个）' : '开始背 ' + n + ' 个';
  } else if (allDone) {
    mainLabel = '词库已全部背过 🎉';
  } else {
    mainLabel = '今日已完成，再背一组';
  }

  return {
    perDay: S.perDay,
    streak: S.streak || 0,
    n: n,
    heroNum: n > 0 ? n : doneCnt,
    heroLab: n > 0 ? '今天还要背' : '今天已完成',
    doneCnt: doneCnt,
    total: total,
    pct: total ? Math.round((doneCnt / total) * 100) : 100,
    learnedCount: S.learned.length,
    totalWords: V.length,
    wrongCount: wrongList().length,
    mainLabel: mainLabel
  };
}

function listWords(keyword) {
  init();
  const kw = String(keyword || '').trim().toLowerCase();
  const out = [];
  for (let i = 0; i < V.length; i++) {
    const w = V[i];
    if (kw && w[0].toLowerCase().indexOf(kw) < 0 && w[1].toLowerCase().indexOf(kw) < 0) continue;
    out.push({
      index: i,
      word: w[0],
      mean: w[1],
      ipa: w[2] || '',
      learned: !!S.seen[i]
    });
    if (out.length >= 200) break;
  }
  return out;
}

function setPerDay(n) {
  init();
  S.perDay = Number(n) || 12;
  save();
}

function resetAll() {
  init();
  S.seen = {};
  S.learned = [];
  S.wrong = {};
  S.days = {};
  S.streak = 0;
  S.lastDay = null;
  S.order = shuffle(V.map(function (_, i) { return i; }));
  sess = null;
  save();
}

module.exports = {
  init: init,
  state: function () {
    init();
    return S;
  },
  getHome: getHome,
  today: today,
  plan: plan,
  remaining: remaining,
  wrongList: wrongList,
  wordAt: wordAt,
  session: session,
  clearSession: clearSession,
  reveal: reveal,
  startStudy: startStudy,
  startReview: startReview,
  answer: answer,
  result: result,
  listWords: listWords,
  setPerDay: setPerDay,
  resetAll: resetAll,
  totalWords: function () { return V.length; }
};
