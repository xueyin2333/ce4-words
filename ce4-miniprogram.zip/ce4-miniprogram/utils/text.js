// 例句里把目标词高亮：切成 [{t:'片段', hit:true/false}] 给 WXML 渲染
function hlParts(text, word) {
  const s = String(text || '');
  const w = String(word || '');
  if (!s || !w) return [{ t: s, hit: false }];

  const safe = w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp('\\b(' + safe + '[a-z]*)', 'ig');
  const parts = [];
  let last = 0;
  let m = re.exec(s);

  while (m) {
    if (m.index > last) parts.push({ t: s.slice(last, m.index), hit: false });
    parts.push({ t: m[0], hit: true });
    last = m.index + m[0].length;
    if (re.lastIndex === m.index) re.lastIndex++; // 防零宽匹配死循环
    m = re.exec(s);
  }

  if (last < s.length) parts.push({ t: s.slice(last), hit: false });
  return parts.length ? parts : [{ t: s, hit: false }];
}

module.exports = { hlParts: hlParts };
