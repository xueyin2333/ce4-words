const store = require('../../utils/store.js');

Page({
  data: {
    perDay: 12,
    streak: 0,
    n: 0,
    heroNum: 0,
    heroLab: '',
    doneCnt: 0,
    total: 0,
    pct: 0,
    learnedCount: 0,
    totalWords: 0,
    wrongCount: 0,
    mainLabel: ''
  },

  onShow() {
    this.setData(store.getHome());
  },

  onStart() {
    const r = store.startStudy();
    if (!r.ok) {
      wx.showToast({ title: '词库已背完一遍，去错词本复习吧', icon: 'none' });
      return;
    }
    wx.navigateTo({ url: '/pages/study/study' });
  },

  onWrong() {
    wx.navigateTo({ url: '/pages/wrong/wrong' });
  },

  onList() {
    wx.switchTab({ url: '/pages/list/list' });
  },

  onSettings() {
    wx.switchTab({ url: '/pages/settings/settings' });
  },

  onShareAppMessage() {
    return {
      title: '四级单词 · 每天背 12 个',
      path: '/pages/index/index'
    };
  }
});
