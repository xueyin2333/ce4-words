const store = require('../../utils/store.js');

Page({
  data: {
    r: null
  },

  onLoad() {
    this.setData({ r: store.result() });
  },

  onContinue() {
    const res = store.startStudy();
    if (!res.ok) {
      wx.showToast({ title: '词库已背完一遍，去错词本复习吧', icon: 'none' });
      return;
    }
    wx.redirectTo({ url: '/pages/study/study' });
  },

  onReview() {
    const res = store.startReview();
    if (!res.ok) return;
    wx.redirectTo({ url: '/pages/study/study' });
  },

  onHome() {
    wx.switchTab({ url: '/pages/index/index' });
  }
});
