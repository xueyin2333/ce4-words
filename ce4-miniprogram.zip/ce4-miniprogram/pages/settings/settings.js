const store = require('../../utils/store.js');

Page({
  data: {
    perDay: 12,
    days: [8, 12, 16, 20],
    learnedCount: 0,
    totalWords: 0,
    wrongCount: 0,
    streak: 0,
    armed: false
  },

  onShow() {
    this.refresh();
  },

  refresh() {
    store.init();
    const S = store.state();
    this.setData({
      perDay: S.perDay,
      learnedCount: S.learned.length,
      totalWords: store.totalWords(),
      wrongCount: store.wrongList().length,
      streak: S.streak || 0,
      armed: false
    });
  },

  onPerDay(e) {
    store.setPerDay(e.currentTarget.dataset.n);
    this.refresh();
  },

  onReset() {
    if (!this.data.armed) {
      this.setData({ armed: true });
      return;
    }
    store.resetAll();
    this.refresh();
    wx.showToast({ title: '进度已清空', icon: 'none' });
  }
});
