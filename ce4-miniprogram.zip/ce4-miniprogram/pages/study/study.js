const store = require('../../utils/store.js');
const text = require('../../utils/text.js');
const speech = require('../../utils/speech.js');

Page({
  data: {
    cur: null,
    revealed: false,
    pos: '',
    pct: 0
  },

  onShow() {
    if (!store.session()) {
      wx.switchTab({ url: '/pages/index/index' });
      return;
    }
    this.sync();
  },

  sync() {
    const s = store.session();
    if (!s || !s.queue.length) return;

    const w = store.wordAt(s.queue[0]);
    const answered = s.answered || 0;
    const total = answered + s.queue.length;

    this.setData({
      cur: {
        word: w.word,
        mean: w.mean,
        ipa: w.ipa,
        ex: w.ex,
        exz: w.exz,
        emoji: w.emoji,
        letter: (w.word.charAt(0) || '?').toUpperCase(),
        exParts: w.ex
          ? text.hlParts(w.ex, w.word).map(function (p, k) {
              return { t: p.t, hit: p.hit, i: k };
            })
          : []
      },
      revealed: !!s.revealed,
      pos: answered + 1 + '/' + total,
      pct: total ? Math.round((answered / total) * 100) : 0
    });
  },

  onReveal() {
    const s = store.session();
    if (!s || s.revealed) return;
    store.reveal();
    this.sync();
  },

  onSpeak() {
    speech.speak(this.data.cur && this.data.cur.word);
  },

  onBad() {
    this.answer(false);
  },

  onGood() {
    this.answer(true);
  },

  answer(ok) {
    const s = store.session();
    if (!s) return;
    if (!s.revealed) {
      wx.showToast({ title: '先点卡片看释义', icon: 'none' });
      return;
    }

    const r = store.answer(ok);
    if (r.finished) {
      wx.redirectTo({ url: '/pages/summary/summary' });
      return;
    }
    this.sync();
  },

  onQuit() {
    store.clearSession();
    const pages = getCurrentPages();
    if (pages.length > 1) {
      wx.navigateBack();
    } else {
      wx.switchTab({ url: '/pages/index/index' });
    }
  }
});
