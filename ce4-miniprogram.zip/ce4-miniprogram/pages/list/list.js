const store = require('../../utils/store.js');

Page({
  data: {
    keyword: '',
    items: [],
    learnedCount: 0,
    totalWords: 0,
    capped: false
  },

  onShow() {
    this.refresh(this.data.keyword);
  },

  onInput(e) {
    const v = e.detail.value;
    this.setData({ keyword: v });
    this.refresh(v);
  },

  onClear() {
    this.setData({ keyword: '' });
    this.refresh('');
  },

  refresh(kw) {
    const items = store.listWords(kw);
    const S = store.state();
    this.setData({
      items: items,
      learnedCount: S.learned.length,
      totalWords: store.totalWords(),
      capped: items.length >= 200 && !String(kw || '').trim()
    });
  }
});
