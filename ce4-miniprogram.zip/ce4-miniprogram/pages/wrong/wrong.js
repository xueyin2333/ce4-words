const store = require('../../utils/store.js');

Page({
  data: {
    items: [],
    count: 0
  },

  onShow() {
    const ids = store.wrongList();
    const S = store.state();
    const items = ids.map(function (i) {
      const w = store.wordAt(i);
      return {
        index: i,
        word: w.word,
        mean: w.mean,
        ipa: w.ipa,
        n: (S.wrong && S.wrong[i]) || 0
      };
    });
    this.setData({ items: items, count: items.length });
  },

  onReview() {
    const res = store.startReview();
    if (!res.ok) return;
    wx.redirectTo({ url: '/pages/study/study' });
  }
});
