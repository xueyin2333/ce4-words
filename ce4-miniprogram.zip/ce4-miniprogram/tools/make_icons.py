#!/usr/bin/env python3
"""生成小程序 tabBar 图标：81x81 PNG，普通态 #7d8590，选中态 #3ddc97。
图形用几何形状画，3 倍超采样后缩放，边缘干净。"""
import os
from PIL import Image, ImageDraw

OUT = "/root/workspace/ce4-miniprogram/images"
SIZE = 81
SS = 4                      # 超采样倍数
S = SIZE * SS
NORMAL = (125, 133, 144, 255)   # #7d8590
ACTIVE = (61, 220, 151, 255)    # #3ddc97

os.makedirs(OUT, exist_ok=True)


def canvas():
    return Image.new("RGBA", (S, S), (0, 0, 0, 0))


def save(img, name):
    small = img.resize((SIZE, SIZE), Image.LANCZOS)
    path = os.path.join(OUT, name)
    small.save(path)
    return small


def rounded(draw, box, radius, color, width):
    draw.rounded_rectangle(box, radius=radius, outline=color, width=width)


def draw_word(d, color):
    """背单词：一张卡片 + 中间一条词条线 + 下方短线"""
    m = 14 * SS
    rounded(d, (m, m + 6 * SS, S - m, S - m - 2 * SS), 7 * SS, color, 3 * SS)
    d.rounded_rectangle((m + 10 * SS, 27 * SS, S - m - 10 * SS, 33 * SS), radius=3 * SS, fill=color)
    d.rounded_rectangle((m + 10 * SS, 45 * SS, S - m - 22 * SS, 51 * SS), radius=3 * SS, fill=color)


def draw_list(d, color):
    """词表：三行，每行一个小圆点 + 一条线"""
    y0, gap = 22 * SS, 18 * SS
    for i in range(3):
        y = y0 + i * gap
        d.ellipse((16 * SS, y - 3 * SS, 22 * SS, y + 3 * SS), fill=color)
        d.rounded_rectangle((30 * SS, y - 3 * SS, 66 * SS, y + 3 * SS), radius=3 * SS, fill=color)


def draw_me(d, color):
    """我的：头 + 肩"""
    cx, cy, r = S // 2, 30 * SS, 11 * SS
    d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=color, width=3 * SS)
    # 肩部：一段圆弧，开口朝下
    box = (cx - 21 * SS, 44 * SS, cx + 21 * SS, 46 * SS + 30 * SS)
    d.arc(box, start=200, end=340, fill=color, width=3 * SS)


def main():
    icons = [("tab-word", draw_word), ("tab-list", draw_list), ("tab-me", draw_me)]
    for name, fn in icons:
        for suffix, color in (("", NORMAL), ("-on", ACTIVE)):
            img = canvas()
            fn(ImageDraw.Draw(img), color)
            save(img, name + suffix + ".png")
            print("生成", name + suffix + ".png")

    # 拼一张预览图，方便人眼核对
    pad, cell = 26, SIZE + 40
    preview = Image.new("RGBA", (cell * 3 + pad, cell * 2 + pad), (13, 17, 23, 255))
    for row, suffix in enumerate(("", "-on")):
        for col, name in enumerate(["tab-word", "tab-list", "tab-me"]):
            img = Image.open(os.path.join(OUT, name + suffix + ".png"))
            x = pad // 2 + col * cell + (cell - SIZE) // 2
            y = pad // 2 + row * cell + (cell - SIZE) // 2
            preview.alpha_composite(img, (x, y))
    preview.save("/tmp/tabbar-preview.png")
    print("预览图 /tmp/tabbar-preview.png")


if __name__ == "__main__":
    main()
