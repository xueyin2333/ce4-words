const store = require('./utils/store.js');

App({
  globalData: {
    launchTime: 0
  },

  onLaunch() {
    this.globalData.launchTime = Date.now();
    store.init();
  },

  onShow() {},

  onError(err) {
    console.error('[app] onError', err);
  }
});
